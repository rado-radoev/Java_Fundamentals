/*
 * Employee.java
 */

/**
 *
 * @author StudentName
 */
public class Employee {
    
	// Name your member variables as follows: firstName, lastName and monthlySalary
    
	// Implement a three-parameter constructor that takes, in order: the first name, last name and monthly salary

	// Your accessor methods should be named following the pattern getVariableName. e.g.: getFirstName
	// Your mutator methods should be named following the pattern setVariableName. e.g.: setFirstName
    
}
