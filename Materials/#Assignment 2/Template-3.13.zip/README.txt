Use the supplied .java file(s) as the basis of your solution to the assignment. Note that, for the purposes of this course, all classes are defined within the default package (in other words, they do not explicitly specify a package).

This assignment must be submitted as a .zip file containing only your solution's .java files named following the convention LastnameFirstInitialExercise#.zip where the '#' is the Exercise number.
For example, my submission for this assignment would be named DukeGExercise3.13.zip). There should be no directories within the zip file.


Expected test program (EmployeeTest.java) console (System.out) output:
Benjamin Bernanke's yearly salary: 14814.72
Paul Volcker's yearly salary: 28148.04
Giving raises...
Benjamin Bernanke's yearly salary: 16296.192000000001
Paul Volcker's yearly salary: 30962.844
Attempting to set a negative salary value...
Benjamin Bernanke's yearly salary: 16296.192000000001