Use the supplied .java file(s) as the basis of your solution to the assignment. Note that, for the purposes of this course, all classes are defined within the default package (in other words, they do not explicitly specify a package).



This assignment must be submitted as a .zip file containing only your solution's .java files named following the convention LastnameFirstInitialExercise#.zip where the '#' is the Exercise number.
For example, my submission for this assignment would be named DukeGExercise5.11.zip). There should be no directories within the zip file.


With regard to sample output: the program's output will vary based on its input, but the text and formatting is expected to conform to the example provided below.



Expected test program (SmallestInt.java) console (System.out) output:

How many integers shall we compare? (Enter a positive integer): -13
Invalid input!
How many integers shall we compare? (Enter a positive integer): 3
Enter value 1: 55
Enter value 2: 4321
Enter value 3: -13
The smallest number entered was: -13