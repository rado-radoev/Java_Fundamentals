// Text printing method
public class Welcome1 {
	
	// main method begins execution of Java application
	public static void main(String[] args) {
		System.out.println("Welcome to Java Programming!");
	} // main method end
} // end class Welcome1
